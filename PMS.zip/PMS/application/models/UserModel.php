<?php
    class UserModel extends CI_Model{

        public function userExist($username, $pass){
            $checkUser = $this->db->get_where('users', ['u_username' => $username, 'u_password' => $pass] );
            if($checkUser->num_rows() > 0 ){
              return $checkUser->row(); 
            } else {
              return false;
            }
        }

        public function allUsers(){
          $users = $this->db->query("SELECT * FROM `users`");
          if ($users->num_rows() > 0 ) {
            return $users->result();
          }
          return false;
        }

        public function addUser($userImage){
            $data = array(
              'u_firstname' => $this->input->post('u_firstname'),
              'u_lastname'  => $this->input->post('u_lastname'),
              'u_username'  => $this->input->post('u_username'),
              'u_picture'   => $userImage,
              'u_password'  => $this->input->post('u_password'),
            );
            $data = $this->security->xss_clean($data);
            return $this->db->insert('users', $data);
        }

        public function delete_user($id){
          return $this->db->delete('users',['u_id'=>$id]);
        }

        public function user_update($id){
          $data = array(
            'u_firstname' =>$this->input->post('u_firstname'),
            'u_lastname'  =>$this->input->post('u_lastname'),
            'u_username'   =>$this->input->post('u_username'), 
            'u_password'  =>$this->input->post('u_password'),

          
          );
          $data = $this->security->xss_clean($data);
          return $this->db->where('u_id', $id)->update('users', $data);
        }

        public function show_single_user($id){
          $user = $this->db->get_where('users', array('u_id' => $id));
          if($user -> num_rows() > 0){
            return $user->row();
          }
        }

        
    }