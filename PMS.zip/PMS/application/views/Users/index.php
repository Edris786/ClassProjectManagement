
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div id="container" class="row-fluid">
		<!-- BEGIN SIDEBAR -->

		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->
		<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<ul class="breadcrumb">
							<li>
                                <a href="http://localhost/PMS/Home"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="#">نرم افزار مدیریت پروژه ها</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">کاربران</a><span class="divider-last">&nbsp;</span></li>
                            <li class="pull-right search-wrap">
                                <form class="hidden-phone">
                                    <div class="search-input-area">
                                        <input id=" " class="search-query" type="text" placeholder="برای دسترسی سریع جستجو کنید">
                                        <i class="icon-search"></i>
                                    </div>
                                </form>
                            </li>
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
                <!-- END PAGE HEADER-->
                
				<!-- BEGIN PAGE CONTENT-->
				<div id="page" class="dashboard">
                    <!-- BEGIN OVERVIEW STATISTIC BLOCKS-->
                    <div class="row-fluid">
                        <div class="span12">
                            <!-- BEGIN EXAMPLE TABLE widget-->
                            <div class="widget">
                                <div class="widget-title">
                                    <h4><i class="icon-reorder"></i>  مدیریت کاربران</h4>
                                    <button data-toggle="modal" data-target="#addUser" style="margin-top: 2px;" class="btn btn-info">اضافه کردن کاربر جدید</button>
                                    <span class="tools">
                                        <a href="javascript:;" class="icon-chevron-down"></a>
                                        <a href="javascript:;" class="icon-remove"></a>
                                    </span>
                                </div>
                                <div class="widget-body">
                                    <table class="table table-striped table-bordered" style="color: black;" id="sample_1">
                                    <thead>
                                        <tr>
                                            <th style="width:8px;">شماره</th>
                                            <th> نام کاربر</th>
                                            <th>نام فامیلی</th>
                                            <th>نام کاربری</th>
                                            <th>عملیه</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($users)):?>
                                        <?php $count = 1; ?>
                                        <?php foreach($users as $user):?>
                                        <tr>
                                            <td><?= $count; ?></td>
                                            <td><?php echo $user -> u_firstname; ?></td>
                                            <td><?php echo $user -> u_lastname; ?></td>
                                            <td><?php echo $user -> u_username; ?></td>
                                            <td>
                                            <a href='<?= base_url("User/delete_user/{$user->u_id}")?>'><button class="btn btn-danger" onclick="return confirm('آیا مطمئن که کاربر را حذف کنید؟')">حذف</button></a>
                                            <a href='<?= base_url("User/update_user/{$user->u_id}")?>'><button class="btn btn-warning">تغییر</button></a>
                                            </td>
                                        </tr>
                                        <?php $count++; ?>
                                        <?php endforeach;?>
                                        <?php endif;?>
                                       
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th style="width:8px;">شماره</th>
                                            <th> نام کاربر</th>
                                            <th>نام فامیلی</th>
                                            <th>نام کاربری</th>
                                            <th>عملیه</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE widget-->
                        </div>
                    </div>
                    <!-- END SQUARE STATISTIC BLOCKS-->
                </div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->
    </div>


        <div class="modal fade" id="addUser" role="dialoge">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" style="color: #37b7f3">ثبت کاربر جدید</h4>
                    </div>
                    <div class="modal-body" id="addUser">
                        <?= form_open_multipart('User/addUser', ['role' => 'form', 'id' => 'myForm', 'class' => 'form-horizontal']); ?>

                        <div class="control-group">
                            <label class="control-label" style="color: black;">نام: </label>
                            <div class="controls">
                                <?= form_input([
                                'id' => 'u_name',
                                'placeholder' => 'نام',
                                'name' => 'u_firstname',
                                'type' => 'text',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('u_firstname', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" style="color: black;">نام فامیلی: </label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'u_lastname',
                                'placeholder' => 'نام فامیلی',
                                'name' => 'u_lastname',
                                'type' => 'text',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('u_lastname', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" style="color: black;">نام کاربری: </label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'u_username',
                                'placeholder' => 'نام کاربری',
                                'name' => 'u_username',
                                'type' => 'text',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('u_username', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" style="color: black;">تصویر کاربر:</label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'userfile',
                                'placeholder' => 'تصویر',
                                'name' => 'userfile',
                                'type' => 'file',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('userfile', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label" style="color: black;">رمز عبور: </label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'u_password',
                                'placeholder' => 'رمز عبور',
                                'name' => 'u_password',
                                'type' => 'password',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('u_password', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                            
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">لغو عملیه</button>
                    <button id="btnSave" type="submit" class="btn btn-primary">ذخیره</button>
                    </div>
                    <?= form_close(); ?>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->


	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	