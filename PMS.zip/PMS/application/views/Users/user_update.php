
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div id="container" class="row-fluid">
		<!-- BEGIN SIDEBAR -->

		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->
		<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<ul class="breadcrumb">
							<li>
                                <a href="http://localhost/PMS/Home"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="#">نرم افزار مدیریت پروژه ها</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">کاربران</a><span class="divider-last">&nbsp;</span></li>
                            <li class="pull-right search-wrap">
                                <form class="hidden-phone">
                                    <div class="search-input-area">
                                        <input id=" " class="search-query" type="text" placeholder="برای دسترسی سریع جستجو کنید">
                                        <i class="icon-search"></i>
                                    </div>
                                </form>
                            </li>
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
                <!-- END PAGE HEADER-->
                
				<!-- BEGIN PAGE CONTENT-->
				<div id="page" class="dashboard">
                    <!-- BEGIN OVERVIEW STATISTIC BLOCKS-->
                    <div class="row-fluid">
                        <div class="span12">
                            <!-- BEGIN EXAMPLE TABLE widget-->
                            <div class="widget">
                                <div class="widget-title">
                                    <h4><i class="icon-reorder"></i>  مدیریت کاربران</h4>
                                    <span class="tools">
                                        <a href="javascript:;" class="icon-chevron-down"></a>
                                        <a href="javascript:;" class="icon-remove"></a>
                                    </span>
                                </div>
                                <div class="widget-body">
                                <div class="modal-header">
                    <h4 class="modal-title" style="color: #37b7f3">ویرایش کاربر </h4>
                    </div>
                    <div class="modal-body">
                        <?= form_open_multipart("User/update_user/{$user->u_id}", ['role' => 'form', 'id' => 'myForm', 'class' => 'form-horizontal']); ?>

                        <div class="control-group">
                            <label class="control-label" style="color: black;">نام: </label>
                            <div class="controls">
                                <?= form_input([
                                'id' => 'u_name',
                                'placeholder' => 'نام',
                                'name' => 'u_firstname',
                                'type' => 'text',
                                'class' => 'input-large',
                                'value'=> set_value('u_firstname', $user->u_firstname)
                                ]); ?>
                                <span class="help-inline"><?= form_error('u_firstname', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" style="color: black;">نام فامیلی: </label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'u_lastname',
                                'placeholder' => 'نام فامیلی',
                                'name' => 'u_lastname',
                                'type' => 'text',
                                'class' => 'input-large',
                                'value'=> set_value('u_lastname', $user->u_lastname)
                                ]); ?>
                                <span class="help-inline"><?= form_error('u_lastname', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" style="color: black;">نام کاربری: </label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'u_username',
                                'placeholder' => 'نام کاربری',
                                'name' => 'u_username',
                                'type' => 'text',
                                'class' => 'input-large',
                                'value'=> set_value('u_username', $user->u_username)
                                ]); ?>
                                <span class="help-inline"><?= form_error('u_username', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
        
                            
                    </div>
                    <div class="modal-footer">
                    <a href="<?= base_url("User")?>"><button type="button" class="btn btn-default pull-left" data-dismiss="modal">لغو عملیه</button></a>
                    <button id="btnSave" type="submit" class="btn btn-primary">ذخیره</button>
                    </div>
                    <?= form_close(); ?>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE widget-->
                        </div>
                    </div>
                    <!-- END SQUARE STATISTIC BLOCKS-->
                </div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->
    </div>




	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	