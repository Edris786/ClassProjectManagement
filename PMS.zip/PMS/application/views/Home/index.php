
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div id="container" class="row-fluid">
		<!-- BEGIN SIDEBAR -->

		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->
		<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<ul class="breadcrumb">
							<li>
                                <a href="http://localhost/PMS/Home"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="#">نرم افزار مدیریت پروژه ها</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">خانه</a><span class="divider-last">&nbsp;</span></li>
                            <li class="pull-right search-wrap">
                                <form class="hidden-phone">
                                    <div class="search-input-area">
                                        <input id=" " class="search-query" type="text" placeholder="برای دسترسی سریع جستجو کنید">
                                        <i class="icon-search"></i>
                                    </div>
                                </form>
                            </li>
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
                <!-- END PAGE HEADER-->
                
				<!-- BEGIN PAGE CONTENT-->
				<div id="page" class="dashboard">
                    <!-- BEGIN OVERVIEW STATISTIC BLOCKS-->
                    <div class="row-fluid circle-state-overview">
                        <div class="span2 responsive" data-tablet="span3" data-desktop="span2">
                            <div class="circle-stat block">
                                <div class="visual">
                                    <div class="circle-state-icon">
                                        <i class="icon-user turquoise-color"></i>
                                    </div>
                                    <input class="knob" data-width="100" data-height="100" data-displayPrevious=true  data-thickness=".2" value="<?= count($users)?>" data-fgColor="#4CC5CD" data-bgColor="#ddd">
                                </div>
                                <div class="details">
                                    <div class="number">
                                    <?= count($users)?>
                                    </div>
                                    <div class="title">کاربران</div>
                                </div>

                            </div>
                        </div>
                        <div class="span2 responsive" data-tablet="span3" data-desktop="span2">
                            <div class="circle-stat block">
                                <div class="visual">
                                    <div class="circle-state-icon">
                                        <i class="icon-tags red-color"></i>
                                    </div>
                                    <input class="knob" data-width="100" data-height="100" data-displayPrevious=true  data-thickness=".2" value="65" data-fgColor="#e17f90" data-bgColor="#ddd"/>
                                </div>
                                <div class="details">
                                    <div class="number">12</div>
                                    <div class="title">پروژه </div>
                                </div>

                            </div>
                        </div>
                        
                        <div class="span2 responsive" data-tablet="span3" data-desktop="span2">
                            <div class="circle-stat block">
                                <div class="visual">
                                    <div class="circle-state-icon">
                                        <i class="icon-shopping-cart green-color"></i>
                                    </div>
                                    <input class="knob" data-width="100" data-height="100" data-displayPrevious=true  data-thickness=".2" value="30" data-fgColor="#a8c77b" data-bgColor="#ddd"/>
                                </div>
                                <div class="details">
                                    <div class="number">13</div>
                                    <div class="title">دپارتمت </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- END OVERVIEW STATISTIC BLOCKS-->

                    <!-- BEGIN SQUARE STATISTIC BLOCKS-->
                    
                    <div class="square-state">
                        <div class="row-fluid">
                            <a class="icon-btn span2" href="#">
                                <i class="icon-barcode"></i>
                                <div>ثبت پروژه جدید</div>
                                <span class="badge badge-important">2</span>
                            </a>
                            <a class="icon-btn span2" href="#">
                                <i class=" icon-group"></i>
                                <div>ثبت کارمند جدید</div>
                                <span class="badge badge-success">4</span>
                            </a>
                            <a class="icon-btn span2" href="#">
                                <i class="icon-bar-chart"></i>
                                <div>ثبت دپارتمنت جدید</div>
                            </a>
                        </div>
                    </div>

                    <!-- END SQUARE STATISTIC BLOCKS-->
                </div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	