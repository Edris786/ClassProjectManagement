<!DOCTYPE html>
<!--
Template Name: Admin Lab Dashboard build with Bootstrap v2.3.1
Template Version: 1.0
Author: Mosaddek Hossain
Website: http://thevectorlab.net/
-->

<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
  <meta charset="utf-8" />
  <title>صفحه ورود به نرم افزار مدیریت پروژه ها</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="description" />
  <meta content="" name="author" />
  <link href="<?= base_url(); ?>template/assets/bootstrap-rtl/css/bootstrap-rtl.min.css" rel="stylesheet" />
  <link href="<?= base_url(); ?>template/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link href="<?= base_url(); ?>template/css/style.css" rel="stylesheet" />
  <link href="<?= base_url(); ?>template/css/style_responsive.css" rel="stylesheet" />
  <link href="<?= base_url(); ?>template/css/style_default.css" rel="stylesheet" id="style_color" />
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body id="login-body">
  <div class="login-header">
      <!-- BEGIN LOGO -->
      <div id="logo" class="center">
          <img src="<?= base_url(); ?>template/img/logo.png" style="width: 120px;" alt="logo" class="center" />
      </div>
      <!-- END LOGO -->
  </div>

  <!-- BEGIN LOGIN -->
  <div id="login">
    <!-- BEGIN LOGIN FORM -->
    <?= form_open('Home/login', ['class' => 'form-vertical no-padding no-margin', 'id' => 'loginform']); ?>
      <div class="lock">
          <i class="icon-lock"></i>
      </div>
      <div class="control-wrap">
          <h4>صفحه ورود به نرم افزار</h4>
          <div class="control-group">
              <div class="controls">
                  <div class="input-prepend">
                      <span class="add-on"><i class="icon-user"></i></span>
                      <?= form_input([
                        'name' => 'username',
                        'type' => 'text',
                        'placeholder' => 'نام کاربری'
                        ]); ?>
                  </div>
              </div>
          </div>
          <div class="control-group">
              <div class="controls">
                  <div class="input-prepend">
                      <span class="add-on"><i class="icon-key"></i></span>
                      <?= form_input([
                        'name' => 'password',
                        'type' => 'password',
                        'placeholder' => 'رمز عبور'
                        ]); ?>
                  </div>
                  

                  <div class="clearfix space5"></div>
              </div>

          </div>
      </div>

      <input type="submit" id="login-btn" class="btn btn-block login-btn" value="ورود" />
      <?= form_close(); ?>
    <!-- END LOGIN FORM -->        
    <!-- BEGIN FORGOT PASSWORD FORM -->
    <form id="forgotform" class="form-vertical no-padding no-margin hide" action="index.html">
      <p class="center">Enter your e-mail address below to reset your password.</p>
      <div class="control-group">
        <div class="controls">
          <div class="input-prepend">
            <span class="add-on"><i class="icon-envelope"></i></span><input id="input-email" type="text" placeholder="Email"  />
          </div>
        </div>
        <div class="space20"></div>
      </div>
      <input type="button" id="forget-btn" class="btn btn-block login-btn" value="Submit" />
    </form>
    <!-- END FORGOT PASSWORD FORM -->
  </div>
  <!-- END LOGIN -->
  <!-- BEGIN COPYRIGHT -->
  <div id="login-copyright">
  صفحه ورود به نرم افزار مدیریت پروژه ها &copy;  2019
  </div>
  <!-- END COPYRIGHT -->
  <!-- BEGIN JAVASCRIPTS -->
  <script src="<?= base_url(); ?>template/js/jquery-1.8.3.min.js"></script>
  <script src="<?= base_url(); ?>template/assets/bootstrap-rtl/js/bootstrap.min.js"></script>
  <script src="<?= base_url(); ?>template/js/jquery.blockui.js"></script>
  <script src="<?= base_url(); ?>template/js/scripts.js"></script>
  <script>
    jQuery(document).ready(function() {     
      App.initLogin();
    });
  </script>
  <!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>