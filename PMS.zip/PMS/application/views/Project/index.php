
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div id="container" class="row-fluid">
		<!-- BEGIN SIDEBAR -->

		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->
		<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<ul class="breadcrumb">
							<li>
                                <a href="http://localhost/PMS/Home"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="#">نرم افزار مدیریت پروژه ها</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">پروژه ها</a><span class="divider-last">&nbsp;</span></li>
                            <li class="pull-right search-wrap">
                                <form class="hidden-phone">
                                    <div class="search-input-area">
                                        <input id=" " class="search-query" type="text" placeholder="برای دسترسی سریع جستجو کنید">
                                        <i class="icon-search"></i>
                                    </div>
                                </form>
                            </li>
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
                <!-- END PAGE HEADER-->
                
				<!-- BEGIN PAGE CONTENT-->
				<div id="page" class="dashboard">
                    <!-- BEGIN OVERVIEW STATISTIC BLOCKS-->
                    <div class="row-fluid">
                        <div class="span12">
                            <!-- BEGIN EXAMPLE TABLE widget-->
                            <div class="widget">
                                <div class="widget-title">
                                    <h4><i class="icon-reorder"></i>  مدیریت پروژه ها</h4>
                                    <button data-toggle="modal" data-target="#addProject" style="margin-top: 2px;" class="btn btn-info">اضافه کردن پروژه جدید</button>
                                    <span class="tools">
                                        <a href="javascript:;" class="icon-chevron-down"></a>
                                        <a href="javascript:;" class="icon-remove"></a>
                                    </span>
                                </div>
                                <div class="widget-body">
                                    <table class="table table-striped table-bordered" style="color: black;" id="sample_1">
                                    <thead>
                                        <tr>
                                            <th style="width:8px;">شماره</th>
                                            <th> نام پروژه</th>
                                            <th class="hidden-phone">بودجه پروژه</th>
                                            <th class="hidden-phone">تاریخ شروع</th>
                                            <th class="hidden-phone">تاریخ ختم</th>
                                            <th class="hidden-phone">عملیه</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($projects)):?>
                                            <?php $count = 1; ?>
                                            <?php foreach($projects as $project):?>
                                            <tr>
                                                <td><?= $count; ?></td>
                                                <td><?php echo $project -> pr_name; ?></td>
                                                <td><?php echo $project -> pr_budget; ?></td>
                                                <td><?php echo $project -> p_startdate; ?></td>
                                                <td><?php echo $project -> p_enddate; ?></td>
                                                <td>
                                                <a href='<?= base_url("Project/delete_project/{$project->pr_id}")?>'><button class="btn btn-danger" onclick="return confirm('آیا مطمئن که کاربر را حذف کنید؟')">حذف</button></a>
                                                <a href='<?= base_url("Project/update_project/{$project->pr_id}")?>'><button class="btn btn-warning">تغییر</button></a>
                                                </td>
                                            </tr>
                                            <?php $count++; ?>
                                            <?php endforeach;?>
                                        <?php endif;?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th style="width:8px;">شماره</th>
                                            <th> نام پروژه</th>
                                            <th class="hidden-phone">بودجه پروژه</th>
                                            <th class="hidden-phone">تاریخ شروع</th>
                                            <th class="hidden-phone">تاریخ ختم</th>
                                            <th class="hidden-phone">عملیه</th>
                                        </tr>
                                    </tfoot>
                                </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE widget-->
                        </div>
                    </div>
                    <!-- END SQUARE STATISTIC BLOCKS-->
                </div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->
    </div>


        <div class="modal fade" id="addProject" role="dialoge">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" style="color: #37b7f3">اضافه کردن پروژه جدید</h4>
                    </div>
                    <div class="modal-body">
                        <?= form_open('Project/add_project', ['role' => 'form', 'id' => 'myForm', 'class' => 'form-horizontal']); ?>

                        <div class="control-group">
                            <label class="control-label" style="color: black;">نام پروژه </label>
                            <div class="controls">
                                <?= form_input([
                                'id' => 'pr_name',
                                'placeholder' => 'نام پروژه',
                                'name' => 'pr_name',
                                'type' => 'text',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('pr_name', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                        
                        <div class="control-group">
                            <label class="control-label" style="color: black;">بودجه  </label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'pr_budget',
                                'placeholder' => 'بودجه',
                                'name' => 'pr_budget',
                                'type' => 'text',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('alt_lastname', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>

                        <div class="control-group">
                            <label class="control-label" style="color: black;">تاریخ شروع</label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'p_startdate',
                                'name' => 'p_startdate',
                                'type' => 'date',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('p_startdate', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>
                        
                        <div class="control-group">
                            <label class="control-label" style="color: black;">تاریخ ختم</label>
                            <div class="controls">
                            <?= form_input([
                                'id' => 'p_enddate',
                                'name' => 'p_enddate',
                                'type' => 'date',
                                'class' => 'input-large'
                                ]); ?>
                                <span class="help-inline"><?= form_error('p_enddate', '<div class="text-danger">', '</div>'); ?></span>
                            </div>
                        </div>   

                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">لغو عملیه</button>
                    <button id="btnSave" type="submit" class="btn btn-primary">ذخیره</button>
                    </div>
                    <?= form_close(); ?>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->


	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	