<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index(){

        if(!$this->session->userdata('u_id')){
			return redirect('login');
		}
        $this->load->model('UserModel');
        $users = $this->UserModel->allUsers();
        $this->load->view('includ/header');
        $this->load->view('includ/sidebar');
        $this->load->view('Home/index', ['users' => $users]);
        $this->load->view('includ/script');
    }
    
    public function login(){

		if($this->session->userdata("u_id")){
			return redirect('/');
        }
        
		$this->form_validation->set_rules('username', 'User Name', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if( $this->form_validation->run() ){
			$username = $this->input->post('username');
			$pass = $this->input->post('password');
			// $pass = md5( $this->input->post('password') );
			$this->load->model('UserModel');
			$userExist = $this->UserModel->userExist($username, $pass);
			 if($userExist){
				 $sessionData = [
					'u_id'          => $userExist->u_id,
					'u_username'   	=> $userExist->u_username,
					'u_firstname' 	=> $userExist->u_firstname,
					'u_lastname' 	=> $userExist->u_lastname,
					'u_picture' 	=> $userExist->u_picture,
				];
				$this->session->set_userdata($sessionData);
				return redirect('/');
			}else{
				$this->session->set_flashdata("massage", "نام کاربری ویا رمز عبور تان درست نمی باشد.");
				redirect('login');
			}
		}else{
			$this->load->view('Home/login');
        }
        
    }
    
    public function signOut() {
		$this->session->unset_userdata('u_id');
		return redirect('/');
	}
}
