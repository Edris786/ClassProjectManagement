<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Project extends CI_Controller {

	public function index(){

        if(!$this->session->userdata('u_id')){
			return redirect('login');
        }

        $this->load->model('ProjectModel');
        $projects = $this->ProjectModel->allProjects();

        $this->load->view('includ/header');
        $this->load->view('includ/sidebar');
        $this->load->view('Project/index',['projects' => $projects]);
        $this->load->view('includ/script');
    }

    public function add_project(){
        $this->form_validation->set_rules('pr_name', 'Project Name', 'required');
        $this->form_validation->set_rules('pr_budget', 'Project badget', 'required');
        if( $this->form_validation->run() ){
          $this->load->model('ProjectModel');
          if( $this->ProjectModel->add_project() ){
            $this->session->set_flashdata('massage', 'پروژه جدید موفقانه ثبت شد.');
            redirect('Project');
          }else{
            $this->session->set_flashdata('massage', 'عمیله ناموفق بود.');
            redirect('Project');
          }
        }else{
            $this->load->model('EmployeeModel');
            $this->load->view('includ/header');
            $this->load->view('includ/sidebar');
            $this->load->view('Project/index');
            $this->load->view('includ/script');
        }
      }

      public function update_project($id){
        $this->form_validation->set_rules('pr_name', 'Project Name', 'required');
        $this->form_validation->set_rules('pr_budget', 'Project badget', 'required');

        if( $this->form_validation->run() ){
          $this->load->model('ProjectModel');
          if( $this->ProjectModel->project_update($id) ){
            $this->session->set_flashdata('massage', 'تغییرات پروژه موفقانه اعمال شد.');
            return redirect('Project');
          }else{
            $this->session->set_flashdata('massage', 'عمیله ناموفق بود.');
            return redirect('Project');
          }
        }else{
          $this->load->model('ProjectModel');
          $project = $this->ProjectModel->show_single_project($id);
          $this->load->view('includ/header');
          $this->load->view('includ/sidebar');
          $this->load->view('Project/updateProject', ['project' => $project]);
          $this->load->view('includ/script');
        }
      }

      public function delete_project($id){
        $this->load->model('ProjectModel');
        if( $this->ProjectModel->delete_project($id) ){
          $this->session->set_flashdata('massage', 'پروژه موفقانه حذف شد.');
        }else{
          $this->session->set_flashdata('massage', 'عمیله ناموفق بود.');
        }
        return redirect('Project');
    }
    
}
