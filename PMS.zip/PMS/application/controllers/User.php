<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function index(){

        if(!$this->session->userdata('u_id')){
			  return redirect('login');
        }
        $this->load->model('UserModel');
        $users = $this->UserModel->allUsers();
        $this->load->view('includ/header');
        $this->load->view('includ/sidebar');
        $this->load->view('Users/index', ['users' => $users]);
        $this->load->view('includ/script');
    }

    public function addUser(){
        if(!$this->session->userdata("u_id")){
			return redirect('login');
		}
            $this->form_validation->set_rules('u_firstname', 'First name','required');
            $this->form_validation->set_rules('u_lastname', 'Last name','required');
            $this->form_validation->set_rules('u_username', 'User name','required');
            $this->form_validation->set_rules('u_password', 'Password','required');

            if($this->form_validation->run() === false){
                $this->load->view('includ/header');
                $this->load->view('includ/sidebar');
                $this->load->view('Users/index');
                $this->load->view('includ/script');
            }else{

                $config['upload_path']          = './userpictures/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 10240;
                $config['max_width']            = 10240;
                $config['max_height']           = 10240;


                $this->load->library('upload', $config);
                if(!$this->upload->do_upload('userfile')){
                    $userImage = 'noimage.jpeg';
                }else{
                    $data = array('upload_data' => $this->upload->data('userfile'));
                    $userImage = $this->upload->file_name;
				}
				
				$this->load->model('UserModel');
                $this->UserModel->addUser($userImage);
                redirect('User');

        }
    }

    public function update_user($id){
        $this->form_validation->set_rules('u_firstname', 'Fist Name', 'required');
        $this->form_validation->set_rules('u_lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('u_username', 'Phone_number', 'required');
        $this->form_validation->set_rules('u_password', 'password', 'required');

        if( $this->form_validation->run() ){
          $this->load->model('UserModel');
          if( $this->UserModel->user_update($id) ){
            $this->session->set_flashdata('massage', 'تغییرات کاربر موفقانه اعمال شد.');
            return redirect('User');
          }else{
            $this->session->set_flashdata('massage', 'عمیله ناموفق بود.');
            return redirect('User');
          }
        }else{
          $this->load->model('UserModel');
          $user = $this->UserModel->show_single_user($id);
          $this->load->view('includ/header');
          $this->load->view('includ/sidebar');
          $this->load->view('Users/user_update', ['user' => $user]);
          $this->load->view('includ/script');
        }
      }

    public function delete_user($id){
        $this->load->model('UserModel');
        if( $this->UserModel->delete_user($id) ){
          $this->session->set_flashdata('massage', 'کاربر موفقانه حذف شد.');
        }else{
          $this->session->set_flashdata('massage', 'عمیله ناموفق بود.');
        }
        return redirect('User');
    }

  
    
}
